import { createClient } from '@/lib/supabase/supabase-ssr';
import { Calendar, MapPin, User, Clock } from 'lucide-react';

const BookingHistory: React.FC = async() => {

       const today = new Date();
     today.setHours(0, 0, 0, 0);
     const isoDate = today.toISOString();
     const supabase = await createClient()
        const { data: { user }, error: userError } = await supabase.auth.getUser()
     const { data: bookings, error } = await supabase
       .from('bookings')
       .select('*')
       .eq('user_id', user?.id)
       .lte('booking_date', isoDate)
       .order('booking_date', { ascending: true });



    if(bookings?.length === 0){
      return <p>No bookings history available</p>
    }


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">Booking History</h1>
        <div className="bg-white rounded-lg px-3 lg:px-4 py-2 shadow-sm border">
          <span className="text-sm text-gray-500">Total Bookings: </span>
          <span className="font-semibold text-blue-600">{bookings?.length}</span>
        </div>
      </div>

      <div className="grid gap-6">
        {bookings && bookings?.length > 0 && bookings.map((booking) => (
          <div key={booking.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6 hover:shadow-md transition-shadow duration-200">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-3">
                  <h3 className="text-xl font-semibold text-gray-800">{booking.service}</h3>
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                    {booking.status}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-blue-500" />
                    <span>{booking.booking_date}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-green-500" />
                    <span>{booking.start_time}-{booking.end_time}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-orange-500" />
                    <span>{booking.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-blue-500" />
                    <span>{booking.attendees} attendees</span>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-xl lg:text-2xl font-bold text-gray-800">{booking.amount}</div>
                <div className="text-sm text-gray-500">Total Cost</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
     
    </div>
  );
};

export default BookingHistory;