import React from 'react';
import { CreditCard, Check, X, Calendar, DollarSign, Zap, Shield, Users } from 'lucide-react';
import { createClient } from '@/lib/supabase/supabase-ssr';
import { PricingSection } from '@/components/landing/pricing-section';
import { pricingData } from '@/lib/constants/suscription';

 const SubscriptionDetails: React.FC = async() => {
 const supabase = await createClient()


    const { data: { user }, error: userError } = await supabase.auth.getUser()
   const {data: currentPlan} = await supabase
       .from('subscriptions').select('*')
        .eq('user_id', user?.id).eq("status", "active");
   const {data: otherPlans} = await supabase
       .from('subscriptions').select('*')
        .eq('user_id', user?.id).neq("status", "active");


        console.log(currentPlan)



  const usageStats = [
    { label: 'Bookings This Month', value: '23', limit: 'Unlimited', color: 'text-blue-600' },
    { label: 'Team Members', value: '3', limit: '5', color: 'text-green-600' },
    { label: 'Storage Used', value: '2.1 GB', limit: '10 GB', color: 'text-orange-600' },
    { label: 'API Calls', value: '1,247', limit: '10,000', color: 'text-purple-600' }
  ];

   let feature = currentPlan && currentPlan?.length > 0 && (pricingData?.monthly.find((item)=> {
              return item?.price == currentPlan[0]?.amount;
            }) || pricingData?.yearly.find((item)=> {
              return item?.price == currentPlan[0]?.amount
            }))

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">Subscription & Billing</h1>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
        
        </div>
      </div>

      {/* Current Plan */}
      {
      currentPlan &&  currentPlan.length > 0 ? (
           <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-4 lg:p-6 border border-blue-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">{currentPlan[0]?.plan_name } Plan</h2>
              <p className="text-gray-600">Your current subscription</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl lg:text-3xl font-bold text-blue-600">${currentPlan[0]?.amount}</div>
            <div className="text-sm text-gray-600">per {currentPlan[0]?.billingCycle}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-6 mb-6">
          <div className="flex items-center space-x-3">
            <Calendar className="w-5 h-5 text-blue-500" />
            <div>
              <div className="text-sm text-gray-600">Next Billing</div>
              <div className="font-semibold">{new Date(currentPlan[0]?.current_period_end).toLocaleDateString('en-GB')}</div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Shield className="w-5 h-5 text-green-500" />
            <div>
              <div className="text-sm text-gray-600">Status</div>
              <div className="font-semibold text-green-600">{currentPlan[0]?.status}</div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <CreditCard className="w-5 h-5 text-orange-500" />
            <div>
              <div className="text-sm text-gray-600">Payment Method</div>
              <div className="font-semibold">**** 4242</div>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {feature && feature?.features.map((feature, index) => (
            <span key={index} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border">
              {feature}
            </span>
          ))}
          {
           
          }
        </div>
      </div>
        ) : <h2 className='text-xl bg-amber-200 px-4 py-6 text-center text-green-500'>No plans subscribed!!</h2>
      }
     


    <PricingSection/>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-6">Recent Billing History</h3>
        <div className="space-y-4">
          {otherPlans?.map((bill, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3 lg:space-x-4">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <div className="font-medium text-gray-800">{bill.invoice}</div>
                  <div className="text-sm text-gray-600">{bill.date}</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 lg:space-x-4">
                <div className="text-right">
                  <div className="font-semibold text-gray-800">{bill.amount}</div>
                  <div className="text-sm text-green-600">{bill.status}</div>
                </div>
              
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionDetails;