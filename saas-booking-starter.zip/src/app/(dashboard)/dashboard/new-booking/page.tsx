'use client'
import React, { useActionState, useState, useEffect } from 'react';
import { Clock, MapPin, Users, Calendar, DollarSign } from 'lucide-react';
import { bookingAction } from '@/app/(dashboard)/dashboard/actions/booking-action';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const initialState = {
  error: undefined as string | undefined,
  success: false
}

const NewBookingForm: React.FC = () => {
  const router = useRouter();
  const [formData, setFormData] = useState({
    service: '',
    date: '',
    startTime: '',
    endTime: '',
    location: '',
    attendees: '',
    notes: ''
  });

  const [formState, formAction, isPending] = useActionState(bookingAction, initialState);

  useEffect(() => {
    if (formState?.error) {
      toast.error(formState.error);
    } else if (formState?.success) {
      toast.success("Booking Completed");
      router.push("/dashboard/upcoming-bookings");
    }
  }, [formState, router]);

  const services = [
    {
      id: 'individual-therapy',
      name: 'Individual Therapy Session',
      price: 50,
      icon: '🧘‍♀️',
      billing: 'Per session',
      description: 'One-on-one therapy session focused on personal growth, mental clarity, and emotional well-being.'
    },
    {
      id: 'couples-therapy',
      name: 'Couples Therapy',
      price: 90,
      icon: '💑',
      billing: 'Per session',
      description: 'Support for couples looking to improve communication, resolve conflict, and rebuild trust.'
    },
    {
      id: 'group-therapy',
      name: 'Group Therapy',
      price: 30,
      icon: '👥',
      billing: 'Per person / per session',
      description: 'Join a supportive group of peers working through similar challenges under guided facilitation.'
    },
    {
      id: 'teen-counseling',
      name: 'Teen Counseling',
      price: 45,
      icon: '🧒',
      billing: 'Per session',
      description: 'Therapy designed for teens navigating stress, anxiety, social pressures, and identity exploration.'
    },
    {
      id: 'family-therapy',
      name: 'Family Therapy',
      price: 100,
      icon: '🏠',
      billing: 'Per session',
      description: 'Structured support for families working on conflict resolution, parenting challenges, and relationships.'
    },
    {
      id: 'mental-health-checkin',
      name: 'Mental Health Check-In',
      price: 25,
      icon: '🧠',
      billing: 'Quick 30-min session',
      description: 'A short session with a therapist to evaluate emotional well-being and recommend next steps.'
    }
  ];

  const locations = [
    'CalmClinic - Main Office',
    'Virtual (Online Session)',
    'Wellness Center - East Wing',
    'Downtown Counseling Hub'
  ];

  const selectedService = services.find(s => s.id === formData.service);

  return (
    <>
      <div className="space-y-6">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Booking Details</h2>
            
            <form 
              action={async (formData: FormData) => {
                const bookingFormData = {
                  service: formData.get('service') as string,
                  date: formData.get('date') as string,
                  start_time: formData.get('start_time') as string,
                  end_time: formData.get('end_time') as string,
                  location: formData.get('location') as string,
                  attendees: formData.get('attendees') as string,
                  notes: formData.get('notes') as string,
                };
                formAction(bookingFormData);
              }} 
              className="space-y-6"
            >
              <Input type="hidden" name='service' value={formData.service}/>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Select Service <span className='text-red-500'>*</span></label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {services.map((service) => (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, service: service.id })}
                      className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                        formData.service === service.id
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="text-2xl mb-2">{service.icon}</div>
                      <div className="text-sm font-medium text-gray-800">{service.name}</div>
                      <div className="text-xs text-green-600">${service.price}/hour</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date <span className='text-red-500'>*</span></label>
                  <div className="relative">
                    <Calendar className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                    <Input
                      type="date"
                      name='date'
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Attendees <span className='text-red-500'>*</span></label>
                  <div className="relative">
                    <Users className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                    <Input
                      type="number"
                      name='attendees'
                      placeholder="Number of people"
                      value={formData.attendees}
                      onChange={(e) => setFormData({ ...formData, attendees: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Start Time <span className='text-red-500'>*</span></label>
                  <div className="relative">
                    <Clock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                    <Input
                      type="time"
                      name='start_time'
                      value={formData.startTime}
                      onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">End Time <span className='text-red-500'>*</span></label>
                  <div className="relative">
                    <Clock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                    <Input
                      type="time"
                      name='end_time'
                      value={formData.endTime}
                      onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location <span className='text-red-500'>*</span></label>
                <div className="relative">
                  <MapPin className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                  <select
                    name='location'
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select a location</option>
                    {locations.map((location) => (
                      <option key={location} value={location}>{location}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Additional Notes</label>
                <textarea
                  name='notes'
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Any special requirements or notes..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <Button
                loading={isPending}
                type="submit"
                className="w-full bg-gradient-to-r from-blue-500 to-green-500 text-white py-3 px-6 rounded-lg font-medium hover:shadow-lg transition-all duration-200"
              >
                Book Now
              </Button>
            </form>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Booking Summary</h3>
              
              {selectedService && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Service</span>
                    <span className="font-medium">{selectedService.name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Rate</span>
                    <span className="font-medium">${selectedService.price}/hour</span>
                  </div>
                  {formData.date && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Date</span>
                      <span className="font-medium">{formData.date}</span>
                    </div>
                  )}
                  {formData.startTime && formData.endTime && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Duration</span>
                      <span className="font-medium">{formData.startTime} - {formData.endTime}</span>
                    </div>
                  )}
                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between text-lg font-semibold">
                      <span>Estimated Total</span>
                      <span className="text-green-600">$120</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-xl p-4 lg:p-6 border border-orange-200">
              <h3 className="text-lg font-semibold text-orange-800 mb-2">💡 Booking Tips</h3>
              <ul className="text-sm text-orange-700 space-y-2">
                <li>• Book at least 24 hours in advance for best availability</li>
                <li>• Group bookings (10+ people) qualify for discounts</li>
                <li>• Free cancellation up to 2 hours before booking</li>
                <li>• Premium locations may have additional fees</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default NewBookingForm;