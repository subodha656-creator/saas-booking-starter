'use client'
import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import BookingHistory from '@/components/dashboard/booking-history';
import NewBookingForm from '@/components/dashboard/new-booking-form';
import UpcomingBookings from '@/components/dashboard/upcoming-booking';
import SubscriptionDetails from '@/components/dashboard/subscription-details';
import Sidebar from '@/components/dashboard/sidebar';


function Layout({
  children
}: {
  children: React.ReactNode
}){
  const [activeTab, setActiveTab] = useState('booking-history');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // const renderContent = () => {
  //   switch (activeTab) {
  //     case 'booking-history':
  //       return <BookingHistory />;
  //     case 'new-booking':
  //       return <NewBookingForm />;
  //     case 'upcoming-bookings':
  //       return <UpcomingBookings />;
  //     case 'subscription':
  //       return <SubscriptionDetails />;
  //     default:
  //       return <BookingHistory/>
  //   }
  // };

  return (
    <div className="min-h-screen bg-gray-50 relative">
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="bg-white p-2 rounded-lg shadow-md border border-gray-200"
        >
          {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {sidebarOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className="flex justify-between">
        <Sidebar 
          // activeTab={activeTab} 
          // setActiveTab={setActiveTab}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
        <main className="flex-1 lg:ml-64 p-4 lg:p-6 pt-16 lg:pt-6">
          <div className="max-w-full">
            {
              children
            }
          </div>
        </main>
      </div>
    </div>
  );
}

export default Layout;