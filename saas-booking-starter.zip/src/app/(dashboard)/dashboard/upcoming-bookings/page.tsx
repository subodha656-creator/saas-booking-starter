import React from 'react';
import { Calendar, Clock, MapPin, Users, Edit3, Trash2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/supabase-ssr';
import { Button } from '@/components/ui/button';
import DeleteBooking from '@/components/dashboard/delete-booking';

 const daysAway = (booking_date: string): number => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const bookingDate = new Date(booking_date);
  bookingDate.setHours(0, 0, 0, 0);
  
  const diffTime = bookingDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
};

const UpcomingBookings: React.FC = async() => {


   const today = new Date();
 today.setHours(0, 0, 0, 0);
 const isoDate = today.toISOString();
         const supabase = await createClient()
        
            const { data: { user }, error: userError } = await supabase.auth.getUser()
 
 const { data: upcomingBookings, error } = await supabase
   .from('bookings')
   .select('*')
   .eq('user_id', user?.id)
   .gte('booking_date', isoDate)
   .order('booking_date', { ascending: true });
  
  

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Confirmed':
        return 'bg-green-100 text-green-700';
      case 'Pending':
        return 'bg-orange-100 text-orange-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getUrgencyColor = (days: number) => {
    if (days <= 3) return 'text-red-600 bg-red-50';
    if (days <= 7) return 'text-orange-600 bg-orange-50';
    return 'text-blue-600 bg-blue-50';
  };

  const getLatestBooking = (bookings: any[]) => {
    if (!bookings || bookings.length === 0) return null;
    
    return bookings.reduce((latest, current) => {
      const currentDate = new Date(current.booking_date);
      const latestDate = new Date(latest.booking_date);
      return currentDate < latestDate ? current : latest;
    });
  };

  const latestBooking = getLatestBooking(upcomingBookings || []);


 if(upcomingBookings?.length === 0) {
  return <p>No bookings available</p>
 }



  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">Upcoming Bookings</h1>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <div className="bg-white rounded-lg px-4 py-2 shadow-sm border">
            <span className="text-sm text-gray-500">Next Booking: </span>
            <span className="font-semibold text-blue-600">{
              daysAway(latestBooking.booking_date)} days</span>
          </div>
          <div className="bg-white rounded-lg px-4 py-2 shadow-sm border">
            <span className="text-sm text-gray-500">Total: </span>
            <span className="font-semibold text-green-600">{upcomingBookings?.length}</span>
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        {upcomingBookings && upcomingBookings?.length > 0 && upcomingBookings.map((booking) => (
          <div key={booking.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6 hover:shadow-md transition-all duration-200">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-3">
                  <h3 className="text-xl font-semibold text-gray-800">{booking.service}</h3>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(booking.status)}`}>
                    {booking.status}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getUrgencyColor(booking.daysUntil)}`}>
                    {latestBooking.booking_date} days
                  </span>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-blue-500" />
                    <span>{booking.booking_date}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-green-500" />
                    <span>{`${booking.start_time} -  ${booking.end_time}`}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-orange-500" />
                    <span>{booking.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-blue-500" />
                    <span>{booking.attendees} attendees</span>
                  </div>
                </div>
                <DeleteBooking id={booking?.id}/>
                
              </div>
              
              <div className="text-right">
                <div className={`text-2xl lg:text-4xl font-bold ${getUrgencyColor(booking.daysUntil).split(' ')[0]}`}>
                  {daysAway(booking.booking_date)}
                </div>
                <div className="text-sm text-gray-500">days away</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
    </div>
  );
};

export default UpcomingBookings;