import { pricingData } from '@/lib/constants/suscription';
import { createClient } from '@/lib/supabase/supabase-ssr';
import { PaymentIntentRequest, PaymentIntentResponse } from '@/types/stripe';
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2025-06-30.basil',
});

export async function POST(request: NextRequest) {
   
  try {
    const { amount, currency = 'usd', plan }: PaymentIntentRequest = await request.json();

    if (!amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Invalid amount' },
        { status: 400 }
      );
    }

     const supabase = await createClient()
     const { data: { user }, error: userError } = await supabase.auth.getUser()
     const today = new Date();
 today.setHours(0, 0, 0, 0);
 const isoDate = today.toISOString();
      const {data: subscription} = await supabase
       .from('subscriptions').select('*')
        .eq('user_id', user?.id).gte("current_period_end", isoDate);

        if(subscription != null && subscription.length > 0){
            return NextResponse.json({present: "Subscription already present"});
        }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), 
      currency,
      automatic_payment_methods: {
        enabled: true,
      },
    });

    const response: PaymentIntentResponse = {
      clientSecret: paymentIntent.client_secret!,
    };

     let feature =  (pricingData?.monthly.find((item)=> {
                  return item?.price == amount;
                }) || pricingData?.yearly.find((item)=> {
                  return item?.price == amount
                }))

                let nextDate = null;
                if(feature != undefined){
  nextDate = new Date();
nextDate.setDate(nextDate.getDate() + feature?.plan_end);
                }
       

     const { data, error } = await supabase
    .from('subscriptions')
    .insert([
      {
        user_id: user?.id,
        plan_name: plan,
        amount: amount,
        stripe_subscription_id: null,
        client_secret: paymentIntent.client_secret,
        status: 'pending',
        current_period_start: new Date(),
        current_period_end: nextDate,
      } ])
    return NextResponse.json({...response, user});
  } catch (error) {
    console.error('Payment intent creation failed:', error);
    return NextResponse.json(
      { error: 'Failed to create payment intent' },
      { status: 500 }
    );
  }
}