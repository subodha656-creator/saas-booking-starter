import React from 'react';
import { Calendar, Clock, MapPin, Users, Edit3, Trash2 } from 'lucide-react';

const UpcomingBookings: React.FC = () => {
  const upcomingBookings = [
    {
      id: '1',
      service: 'Executive Meeting Room',
      date: '2024-01-25',
      time: '10:00 - 12:00',
      location: 'Conference Center A',
      attendees: 6,
      status: 'Confirmed',
      daysUntil: 5
    },
    {
      id: '2',
      service: 'Team Workshop Space',
      date: '2024-01-28',
      time: '14:00 - 16:30',
      location: 'Creative Hub B',
      attendees: 15,
      status: 'Pending',
      daysUntil: 8
    },
    {
      id: '3',
      service: 'Private Office',
      date: '2024-02-02',
      time: '09:00 - 11:00',
      location: 'Business Center C',
      attendees: 4,
      status: 'Confirmed',
      daysUntil: 13
    },
    {
      id: '4',
      service: 'Event Hall',
      date: '2024-02-15',
      time: '18:00 - 22:00',
      location: 'Grand Venue D',
      attendees: 80,
      status: 'Confirmed',
      daysUntil: 26
    }
  ];



  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Confirmed':
        return 'bg-green-100 text-green-700';
      case 'Pending':
        return 'bg-orange-100 text-orange-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getUrgencyColor = (days: number) => {
    if (days <= 3) return 'text-red-600 bg-red-50';
    if (days <= 7) return 'text-orange-600 bg-orange-50';
    return 'text-blue-600 bg-blue-50';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">Upcoming Bookings</h1>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <div className="bg-white rounded-lg px-4 py-2 shadow-sm border">
            <span className="text-sm text-gray-500">Next Booking: </span>
            <span className="font-semibold text-blue-600">5 days</span>
          </div>
          <div className="bg-white rounded-lg px-4 py-2 shadow-sm border">
            <span className="text-sm text-gray-500">Total: </span>
            <span className="font-semibold text-green-600">{upcomingBookings.length}</span>
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        {upcomingBookings.map((booking) => (
          <div key={booking.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6 hover:shadow-md transition-all duration-200">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-3">
                  <h3 className="text-xl font-semibold text-gray-800">{booking.service}</h3>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(booking.status)}`}>
                    {booking.status}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getUrgencyColor(booking.daysUntil)}`}>
                    {booking.daysUntil} days
                  </span>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-blue-500" />
                    <span>{booking.date}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-green-500" />
                    <span>{booking.time}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-orange-500" />
                    <span>{booking.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-blue-500" />
                    <span>{booking.attendees} attendees</span>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                  <button className="flex items-center space-x-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                    <Edit3 className="w-4 h-4" />
                    <span>Edit</span>
                  </button>
                  <button className="flex items-center space-x-2 px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors duration-200">
                    <Trash2 className="w-4 h-4" />
                    <span>Cancel</span>
                  </button>
                </div>
              </div>
              
              <div className="text-right">
                <div className={`text-2xl lg:text-4xl font-bold ${getUrgencyColor(booking.daysUntil).split(' ')[0]}`}>
                  {booking.daysUntil}
                </div>
                <div className="text-sm text-gray-500">days away</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 text-center">
          <div className="text-2xl font-bold text-blue-600 mb-2">2</div>
          <div className="text-gray-600">This Week</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 text-center">
          <div className="text-2xl font-bold text-green-600 mb-2">4</div>
          <div className="text-gray-600">This Month</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 text-center">
          <div className="text-2xl font-bold text-orange-600 mb-2">1</div>
          <div className="text-gray-600">Needs Action</div>
        </div>
      </div>
    </div>
  );
};

export default UpcomingBookings;