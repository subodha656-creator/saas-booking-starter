import React, { useActionState, useState } from 'react';
import { Clock, MapPin, Users, Calendar, DollarSign } from 'lucide-react';
import { Button } from '../ui/button';
import { bookingAction } from '@/app/(dashboard)/dashboard/actions/booking-action';
import { useRouter } from 'next/navigation';
import { Input } from '../ui/input';



const initialState = {
  error: undefined as string | undefined,
  success: false
}

const NewBookingForm: React.FC = () => {

    const router = useRouter();
  const [formData, setFormData] = useState({
    service: '',
    date: '',
    startTime: '',
    endTime: '',
    location: '',
    attendees: '',
    notes: ''
  });

  const services = [
  { id: 'individual-therapy', name: 'Individual Therapy Session', price: 60, icon: '🧘' },
  { id: 'couples-therapy', name: 'Couples Therapy Session', price: 90, icon: '❤️' },
  { id: 'group-therapy', name: 'Group Therapy (Up to 5)', price: 40, icon: '👥' },
  { id: 'child-therapy', name: 'Child & Adolescent Counseling', price: 70, icon: '🧒' },
  { id: 'online-consultation', name: 'Online Consultation (Video)', price: 50, icon: '💻' },
  { id: 'psychiatric-eval', name: 'Psychiatric Evaluation', price: 100, icon: '🧠' }
];





 const locations = [
  'CalmClinic - Main Office',
  'Virtual (Online Session)',
  'Wellness Center - East Wing',
  'Downtown Counseling Hub'
];
const selectedService = services.find(s => s.id === formData.service);

    const [formState, formAction, isPending] = useActionState(bookingAction, initialState)


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">New Booking</h1>
        <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg px-4 py-2">
          <span className="text-sm font-medium">Quick Book</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">Booking Details</h2>
          
          <form 
  action={async (formData: FormData) => {
    const bookingFormData = {
      service: formData.get('service') as string,
      date: formData.get('date') as string,
      start_time: formData.get('start_time') as string,
      end_time: formData.get('end_time') as string,
      location: formData.get('location') as string,
      attendees: formData.get('attendees') as string,
      notes: formData.get('notes') as string,
    };
    formAction(bookingFormData);
    if(formState?.success) {
      setFormData({
        service: '',
        date: '',
        startTime: '',
        endTime: '',
        location: '',
        attendees: '',
        notes: ''
      });

      router.push('/dashboard/checkout');
    }
  }} 
  className="space-y-6"
>
            <p className='text-lg text-red-600 mb-4'>
                {
                    formState?.error && (
                        <span className="text-xl text-red-600">{formState.error}</span>
                    )
                }
            </p>
            <Input type="hidden"  name='service' value={formData.service}/>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">Select Service</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {services.map((service) => (
                  <button
                    key={service.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, service: service.id })}
                    className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                      formData.service === service.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="text-2xl mb-2">{service.icon}</div>
                    <div className="text-sm font-medium text-gray-800">{service.name}</div>
                    <div className="text-xs text-green-600">${service.price}/hour</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                <div className="relative">
                  <Calendar className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                  <Input
                    type="date"
                    name='date'
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Attendees</label>
                <div className="relative">
                  <Users className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                  <Input
                    type="number"
                    name='attendees'
                    placeholder="Number of people"
                    value={formData.attendees}
                    onChange={(e) => setFormData({ ...formData, attendees: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Start Time</label>
                <div className="relative">
                  <Clock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                  <Input
                    type="time"
                    name='start_time'
                    value={formData.startTime}
                    onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">End Time</label>
                <div className="relative">
                  <Clock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                  <Input
                    type="time"
                    name='end_time'
                    value={formData.endTime}
                    onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
              <div className="relative">
                <MapPin className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                <select
                    name='location'
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select a location</option>
                  {locations.map((location) => (
                    <option key={location} value={location}>{location}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Additional Notes</label>
              <textarea
                name='notes'
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Any special requirements or notes..."
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <Button
            loading={isPending}
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-green-500 text-white py-3 px-6 rounded-lg font-medium hover:shadow-lg transition-all duration-200"
            >
              Book Now
            </Button>
          </form>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Booking Summary</h3>
            
            {selectedService && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Service</span>
                  <span className="font-medium">{selectedService.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Rate</span>
                  <span className="font-medium">${selectedService.price}/hour</span>
                </div>
                {formData.date && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Date</span>
                    <span className="font-medium">{formData.date}</span>
                  </div>
                )}
                {formData.startTime && formData.endTime && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Duration</span>
                    <span className="font-medium">{formData.startTime} - {formData.endTime}</span>
                  </div>
                )}
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between text-lg font-semibold">
                    <span>Estimated Total</span>
                    <span className="text-green-600">$120</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-xl p-4 lg:p-6 border border-orange-200">
            <h3 className="text-lg font-semibold text-orange-800 mb-2">💡 Booking Tips</h3>
            <ul className="text-sm text-orange-700 space-y-2">
              <li>• Book at least 24 hours in advance for best availability</li>
              <li>• Group bookings (10+ people) qualify for discounts</li>
              <li>• Free cancellation up to 2 hours before booking</li>
              <li>• Premium locations may have additional fees</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewBookingForm;