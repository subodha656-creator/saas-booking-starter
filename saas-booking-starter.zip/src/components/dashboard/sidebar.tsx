import React, { useState } from 'react';
import { LayoutDashboard, Calendar, Plus, Clock, CreditCard, Settings, HelpCircle, LogOut } from 'lucide-react';
import { Button } from '../ui/button';
import { logOut } from '@/app/(dashboard)/dashboard/actions/logout-action';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import LogoutModal from '../auth/logout-modal';

interface SidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const routes = [
    {
        id: "booking-history",
        href: "/dashboard/",
    },
    {
        id: "new-booking",
        href: "/dashboard/new-booking",
    },
    {
        id: "upcoming-bookings",
        href: "/dashboard/upcoming-bookings",
    },
    {
        id: "subscription",
        href: "/dashboard/subscription",
    },
    {
        id: "settings",
        href: "/dashboard/settings",
    },
    {
        id: "help",
        href: "/dashboard/help",
    }
];


 const menuItems = [
    {
      id: 'booking-history',
      label: 'Booking History',
      icon: Calendar,
    },
    {
      id: 'new-booking',
      label: 'New Booking Form',
      icon: Plus,
    },
    {
      id: 'upcoming-bookings',
      label: 'Upcoming Bookings',
      icon: Clock,
    },
    {
      id: 'subscription',
      label: 'Plan/Subscription Details',
      icon: CreditCard,
    }
  ];

  const bottomMenuItems = [
    { id: 'logout', label: 'Logout', icon: LogOut }
  ];





const Sidebar: React.FC<SidebarProps> = ({sidebarOpen, setSidebarOpen }) => {
 
    const [activeTab, setActiveTab] = useState<string>("");
    const pathName = usePathname();
    const [logoutModal, setLogoutModal] = useState(false);


    const handleLogout = async () => {
        setLogoutModal(true);
    }

  return (
    <>
    {
      logoutModal && <LogoutModal modalOpen={logoutModal} setModalOpen={setLogoutModal}/>
    }
    <aside className={`fixed left-0 top-0 h-full w-64 bg-white shadow-sm border-r border-gray-100 z-40 transform transition-transform duration-300 ease-in-out ${
      sidebarOpen ? 'translate-x-0' : '-translate-x-full'
    } lg:translate-x-0`}>
      <div className="p-6 border-b border-gray-100">
        <Link href={"/"} className="flex items-center space-x-3">
         <Image width={240} height={180} src="/assets/image.png" alt="Logo" className=" rounded-full" />
        </Link>
      </div>
      
      <div className="px-4 py-2">
        <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-3">MENU</p>
      </div>
      
      <nav className="mt-6">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <Link
            href={routes.find(route => route.id === item.id)?.href || '#'}
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setSidebarOpen(false);
              }}
              className={`w-full flex items-center space-x-3 px-6 py-2.5 text-left transition-all duration-200 ${
                isActive
                  ? 'bg-[#10b981] text-white rounded-lg'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg mx-3'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
      
      <div className="px-4 py-2 mt-8">
        <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-3">GENERAL</p>
      </div>
      
      <div className="mt-2">
        {bottomMenuItems.map((item) => {
          const Icon = item.icon;
          
          return (
            <Button
            onClick={handleLogout}
              key={item.id}
              className="w-full flex items-center space-x-3 px-2 py-2.5 text-left transition-all bg-white duration-200 text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg"
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm font-medium">{item.label}</span>
            </Button>
          );
        })}
      </div>
      
    
    </aside>
    </>
  );
};

export default Sidebar;