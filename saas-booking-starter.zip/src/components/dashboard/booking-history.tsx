import React from 'react';
import { Calendar, MapPin, User, Clock } from 'lucide-react';

const BookingHistory: React.FC = () => {
  const bookings = [
    {
      id: '1',
      service: 'Executive Meeting Room',
      date: '2024-01-15',
      time: '09:00 - 11:00',
      location: 'Conference Center A',
      attendees: 8,
      status: 'Completed',
      amount: '$120'
    },
    {
      id: '2',
      service: 'Team Workshop Space',
      date: '2024-01-10',
      time: '14:00 - 17:00',
      location: 'Creative Hub B',
      attendees: 12,
      status: 'Completed',
      amount: '$180'
    },
    {
      id: '3',
      service: 'Private Office',
      date: '2024-01-05',
      time: '10:00 - 12:00',
      location: 'Business Center C',
      attendees: 3,
      status: 'Completed',
      amount: '$90'
    },
    {
      id: '4',
      service: 'Event Hall',
      date: '2023-12-28',
      time: '18:00 - 22:00',
      location: 'Grand Venue D',
      attendees: 50,
      status: 'Completed',
      amount: '$350'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">Booking History</h1>
        <div className="bg-white rounded-lg px-3 lg:px-4 py-2 shadow-sm border">
          <span className="text-sm text-gray-500">Total Bookings: </span>
          <span className="font-semibold text-blue-600">{bookings.length}</span>
        </div>
      </div>

      <div className="grid gap-6">
        {bookings.map((booking) => (
          <div key={booking.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6 hover:shadow-md transition-shadow duration-200">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-3">
                  <h3 className="text-xl font-semibold text-gray-800">{booking.service}</h3>
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                    {booking.status}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-blue-500" />
                    <span>{booking.date}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-green-500" />
                    <span>{booking.time}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-orange-500" />
                    <span>{booking.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-blue-500" />
                    <span>{booking.attendees} attendees</span>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-xl lg:text-2xl font-bold text-gray-800">{booking.amount}</div>
                <div className="text-sm text-gray-500">Total Cost</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="bg-white rounded-xl p-4 lg:p-6 shadow-sm border border-gray-200">
        <div className="text-center">
          <div className="text-2xl lg:text-3xl font-bold text-blue-600 mb-2">$740</div>
          <div className="text-gray-600">Total Spent This Month</div>
        </div>
      </div>
    </div>
  );
};

export default BookingHistory;