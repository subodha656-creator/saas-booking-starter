import React from 'react';
import { CreditCard, Check, X, Calendar, DollarSign, Zap, Shield, Users } from 'lucide-react';

const SubscriptionDetails: React.FC = () => {
  const currentPlan = {
    name: 'Professional',
    price: 49,
    billingCycle: 'monthly',
    nextBilling: '2024-02-15',
    status: 'Active',
    features: [
      'Unlimited bookings',
      'Priority support',
      'Advanced analytics',
      'Team management',
      'Custom branding',
      'API access'
    ]
  };

  const plans = [
    {
      name: 'Basic',
      price: 19,
      popular: false,
      features: [
        'Up to 10 bookings/month',
        'Email support',
        'Basic analytics',
        'Single user',
        'Standard locations'
      ]
    },
    {
      name: 'Professional',
      price: 49,
      popular: true,
      features: [
        'Unlimited bookings',
        'Priority support',
        'Advanced analytics',
        'Up to 5 team members',
        'Premium locations',
        'Custom branding'
      ]
    },
    {
      name: 'Enterprise',
      price: 99,
      popular: false,
      features: [
        'Everything in Professional',
        'Dedicated account manager',
        'Custom integrations',
        'Unlimited team members',
        'White-label solution',
        'SLA guarantee'
      ]
    }
  ];

  const usageStats = [
    { label: 'Bookings This Month', value: '23', limit: 'Unlimited', color: 'text-blue-600' },
    { label: 'Team Members', value: '3', limit: '5', color: 'text-green-600' },
    { label: 'Storage Used', value: '2.1 GB', limit: '10 GB', color: 'text-orange-600' },
    { label: 'API Calls', value: '1,247', limit: '10,000', color: 'text-purple-600' }
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-800">Subscription & Billing</h1>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
            Manage Billing
          </button>
          <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors duration-200">
            Download Invoice
          </button>
        </div>
      </div>

      {/* Current Plan */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-4 lg:p-6 border border-blue-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">{currentPlan.name} Plan</h2>
              <p className="text-gray-600">Your current subscription</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl lg:text-3xl font-bold text-blue-600">${currentPlan.price}</div>
            <div className="text-sm text-gray-600">per {currentPlan.billingCycle}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-6 mb-6">
          <div className="flex items-center space-x-3">
            <Calendar className="w-5 h-5 text-blue-500" />
            <div>
              <div className="text-sm text-gray-600">Next Billing</div>
              <div className="font-semibold">{currentPlan.nextBilling}</div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Shield className="w-5 h-5 text-green-500" />
            <div>
              <div className="text-sm text-gray-600">Status</div>
              <div className="font-semibold text-green-600">{currentPlan.status}</div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <CreditCard className="w-5 h-5 text-orange-500" />
            <div>
              <div className="text-sm text-gray-600">Payment Method</div>
              <div className="font-semibold">**** 4242</div>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {currentPlan.features.map((feature, index) => (
            <span key={index} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border">
              {feature}
            </span>
          ))}
        </div>
      </div>

      {/* Usage Statistics */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-6">Usage Statistics</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {usageStats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className={`text-2xl font-bold ${stat.color} mb-1`}>{stat.value}</div>
              <div className="text-sm text-gray-600 mb-1">{stat.label}</div>
              <div className="text-xs text-gray-500">of {stat.limit}</div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div 
                  className={`h-2 rounded-full bg-gradient-to-r ${
                    stat.color.includes('blue') ? 'from-blue-400 to-blue-600' : 
                    stat.color.includes('green') ? 'from-green-400 to-green-600' :
                    stat.color.includes('orange') ? 'from-orange-400 to-orange-600' :
                    'from-purple-400 to-purple-600'
                  }`}
                  style={{ width: '60%' }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Available Plans */}
      <div className="space-y-6">
        <h3 className="text-xl font-semibold text-gray-800">Available Plans</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
          {plans.map((plan, index) => (
            <div key={index} className={`bg-white rounded-xl shadow-sm border-2 p-4 lg:p-6 relative ${
              plan.popular ? 'border-blue-500' : 'border-gray-200'
            }`}>
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-blue-500 to-green-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Current Plan
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h4 className="text-xl font-bold text-gray-800 mb-2">{plan.name}</h4>
                <div className="text-3xl font-bold text-gray-800 mb-1">${plan.price}</div>
                <div className="text-sm text-gray-600">per month</div>
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              <button 
                className={`w-full py-3 px-4 rounded-lg font-medium transition-colors duration-200 ${
                  plan.popular
                    ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
                disabled={plan.popular}
              >
                {plan.popular ? 'Current Plan' : 'Upgrade'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Billing History */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 lg:p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-6">Recent Billing History</h3>
        <div className="space-y-4">
          {[
            { date: '2024-01-15', amount: '$49.00', status: 'Paid', invoice: 'INV-2024-001' },
            { date: '2023-12-15', amount: '$49.00', status: 'Paid', invoice: 'INV-2023-012' },
            { date: '2023-11-15', amount: '$49.00', status: 'Paid', invoice: 'INV-2023-011' }
          ].map((bill, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3 lg:space-x-4">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <div className="font-medium text-gray-800">{bill.invoice}</div>
                  <div className="text-sm text-gray-600">{bill.date}</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 lg:space-x-4">
                <div className="text-right">
                  <div className="font-semibold text-gray-800">{bill.amount}</div>
                  <div className="text-sm text-green-600">{bill.status}</div>
                </div>
                <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionDetails;