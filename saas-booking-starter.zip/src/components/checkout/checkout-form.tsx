'use client';

import { useContext, useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import {
  Elements,
  CardElement,
  useStripe,
  useElements
} from '@stripe/react-stripe-js';
import { Button } from '@headlessui/react';
import { CheckoutContext } from '@/context/checkout-context';
import { supabase } from '@/lib/supabase/client';
import { toast } from 'sonner';


export function SimplePaymentForm() {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const {price, plan} = useContext(CheckoutContext);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) return;

    setLoading(true);
    setMessage('');

    try {
      // Create payment intent
      const { clientSecret, user, present } = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: price, plan }),
      }).then(r => r.json());


      if(present){
        toast.error("Subscription already present");
      }

      const { error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement)!,
        }
      });

      if (error) {
        setMessage(error.message || 'Payment failed');
      } else {
        const update = await supabase
    .from('subscriptions')
    .update({ status: 'active' })
    .eq('user_id', user.id); 
        setMessage('Payment succeeded!');
        console.log(update)
      }
    } catch (error) {
      setMessage('Something went wrong');
      console.error(error);
    }

    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: '400px', margin: '20px' }}>
      <div style={{ marginBottom: '20px' }}>
        <CardElement options={{
          style: {
            base: {
              fontSize: '16px',
              color: '#424770',
              '::placeholder': { color: '#aab7c4' },
            },
          },
        }} />
      </div>
      
      <Button 
        type="submit" 
        disabled={!stripe || loading}
        style={{
          padding: '12px 24px',
          backgroundColor: loading ? '#ccc' : '#5469d4',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: loading ? 'not-allowed' : 'pointer',
        }}
      >
        {loading ? 'Processing...' : `pay $${price}`}
      </Button>
      
      {message && <div style={{ marginTop: '10px', color: message.includes('succeeded') ? 'green' : 'red' }}>{message}</div>}
    </form>
  );
}